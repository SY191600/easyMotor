# easyMotor/__init__.py
from .core import  motorSTFT, motorFFT

__version__ = "0.2.0"