# easyMotor/__init__.py
from .core import  MotorToothHarmonicCalculator,motorSTFT, motorFFT

__version__ = "0.3.0"